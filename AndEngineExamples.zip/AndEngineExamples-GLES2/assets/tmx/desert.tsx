<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Desert" tilewidth="32" tileheight="32" spacing="3" margin="2">
	<image source="gfx/desert_tiled.png"/>
	<tile id="30">
		<properties>
			<property name="cactus" value="true"/>
		</properties>
	</tile>
</tileset>
