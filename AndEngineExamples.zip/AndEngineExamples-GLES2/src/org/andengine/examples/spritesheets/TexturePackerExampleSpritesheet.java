// Definitions for sprite sheet texturepackerexample
// Created with www.texturepacker.com

// $TexturePacker:SmartUpdate:c7fde2bcfc878112620c417ecfd0e44e$

package org.andengine.examples.spritesheets;

public interface TexturePackerExampleSpritesheet
{
	public static final int FACE_BOX_ID = 0;
	public static final int FACE_CIRCLE_TILED_ID = 1;
	public static final int FACE_HEXAGON_TILED_ID = 2;
	public static final int FACE_TRIANGLE_TILED_ID = 3;
}
