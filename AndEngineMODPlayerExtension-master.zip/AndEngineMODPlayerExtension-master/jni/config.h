/* Android config.h */

#define SYSCONFDIR "/sdcard/xmp"	/* FIXME */
