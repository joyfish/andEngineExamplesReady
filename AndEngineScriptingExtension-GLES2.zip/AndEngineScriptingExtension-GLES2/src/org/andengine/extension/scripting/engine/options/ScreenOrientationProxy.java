package org.andengine.extension.scripting.engine.options;

public class ScreenOrientationProxy {
    public static native void nativeInitClass();
}
