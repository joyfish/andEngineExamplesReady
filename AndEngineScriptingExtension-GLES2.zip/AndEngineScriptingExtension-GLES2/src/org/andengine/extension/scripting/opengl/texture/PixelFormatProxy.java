package org.andengine.extension.scripting.opengl.texture;

public class PixelFormatProxy {
    public static native void nativeInitClass();
}
