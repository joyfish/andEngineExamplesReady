package org.andengine.extension.scripting.opengl.vbo;

public class DrawTypeProxy {
    public static native void nativeInitClass();
}
